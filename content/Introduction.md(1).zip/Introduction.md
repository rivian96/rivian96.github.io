# Introduction

**What is a Malware**

**Malware** (short for **malicious software**) is any software intentionally designed to cause damage to computers, servers, networks, or data. It is used by cybercriminals to steal, encrypt, or delete data, hijack systems, spy on user activity, or disrupt operations.

‍

**why malware analysis is Important**

Malware analysis is important because it helps us understand how harmful software works, what it targets, and how it spreads. This knowledge allows security tools to detect and block threats more effectively. By analyzing malware early, we can reduce damage, respond faster to attacks, and improve system recovery. It also helps in identifying the attackers and contributes to shared threat intelligence, which keeps others safe from similar attacks.

‍

  **Malware Packing**

**Packing** is like wrapping a program in layers to hide its contents. Malware authors use packers to **compress or encrypt** the original program and add a small **unpacking stub**. The stub is a tiny piece of code that runs first. When the packed file is executed, the stub **decompresses** (or decrypts) the real malicious code into memory and then hands control to it ([courses.cs.umbc.edu](https://courses.cs.umbc.edu/undergraduate/CMSC491malware/CMSC%20449%20-%20Lec3%20-%20Hashing%20and%20Packing.pdf#:~:text=%EF%82%A7%20Compress%20original%20program%20and,into%20memory%20and%20runs%20it) ,[redscan.com](https://www.redscan.com/news/redscan-labs-malware-unpacking-uncover-hidden-cyber-threats/#:~:text=Software%20packers%20function%20by%20compressing,a%20decoder%20stub%20for%20decompression)). This means on disk you only see a wrapper, not the actual malware. Packing makes static analysis very hard, because the real code (and its strings or import table) stays hidden until runtime.

‍

**Impact of Packing on Static Malware Analysis**

* Analysts only see the unpacking stub and seemingly random (high entropy) data.
* Readable strings, function names, and useful metadata are often missing or obfuscated.
* The Import Table is minimal or manipulated, hiding actual API calls.
* Section names and structures are altered (`.text`​ becomes `UPX0`​, etc.), making the file suspicious and harder to analyze statically.
* Disassemblers like Ghidra or IDA show misleading or incomplete code paths until the file is unpacked

‍

**Impact  of packing on dynamic analysis**

* When executed, the stub unpacks the real malware code into memory.
* Analysts can observe the real code after unpacking.
* Memory dumps after unpacking reveal the original malware.

‍

**Packing** is like putting your program into a locked box.The box hides the real code, making it harder for defenders to read or change it.When you run the packed program, it first **unpacks** itself in memory, then does its real job.

```mathematica
Original Program (on disk) 
  +------------+-----------+
  | .text (code) | .idata  |
  | .rdata (.data)         |
  | ... (other sections)   |
  +------------------------+
  Entry point here ⬇︎

Packed Program (on disk after packing)
  +----------------------+
  | Stub (decompressor)  |  <-- contains code to unpack
  | Compressed data      |  (the original code encrypted)
  | (filler/empty space) |
  +----------------------+
  Entry point is at Stub ⬇︎
```

‍

The packer takes the original executable (with its code, data, imports, etc.) and **compresses or encrypts** its contents. It then creates a new executable with a **new header and stub**. For example, UPX (a common packer) names its sections `UPX0`​, `UPX1`​, etc., instead of `.text`​ or `.data`​[redscan.com](https://www.redscan.com/news/redscan-labs-malware-unpacking-uncover-hidden-cyber-threats/#:~:text=The%20next%20image%20shows%20sections,109%20Image%3A%20How%20to)​[medium.com](https://medium.com/ax1al/packing-and-obfuscation-fe6b03bbc267#:~:text=Upx%20is%20commonly%20used%20packer,3%20main%20part%20which%20are). The original entry point (OEP) of the program is replaced by the packer stub. This stub is a tiny loader program whose job is to restore the original program in memory[7orvs.github.io](https://7orvs.github.io/tutorials%20summaries/packing-notes-part1/#:~:text=A%20,to%20decrypt%20the%20packed%20file) [courses.cs.umbc.edu](https://courses.cs.umbc.edu/undergraduate/CMSC491malware/CMSC%20449%20-%20Lec3%20-%20Hashing%20and%20Packing.pdf#:~:text=%EF%82%A7%20Compress%20original%20program%20and,into%20memory%20and%20runs%20it).

‍

When you run the packed executable, the operating system loads this stub into memory and begins executing it. The stub allocates memory, decompresses or decrypts the original program into that space, and rebuilds the import table and other metadata.

Finally, the stub jumps to the now-unpacked original entry point (OEP), transferring control to the real malware code.

‍

```mathematica
Runtime unpacking (in memory):
  [OS loads packed EXE] ---> [Stub runs]
      |
      v
  Stub does:
    - Allocate memory space 
    - Decompress original code into it 
    - Fix up Import Table (using LoadLibrary/GetProcAddress)
    - Jump to Original Entry Point

  After this:
  [Memory: Original code runs]
```

‍

**Runtime Flow Diagram**

```mathematica
Packed EXE (disk) --> Stub runs (allocates memory, unpacks code, fixes imports) --> Original code executes in memory

                                Runtime
  [Disk]               [Memory after unpack]               
  +------------+        +------------------+                  
  | Stub code  | -----> | Unpacked .text   |  (Original code) 
  | Compressed |        | Unpacked .data   |  (Data restored)  
  | data blob  |        | IAT rebuilt      |  (Imports resolved) 
  +------------+        +------------------+                  
```

‍

**UPX a common “packer” with built‑in “unpacker”** 

* **UPX** is a free tool that both packs and unpacks executables.
* To **pack**, you run

```mathematica
upx <sample>  
```

To **unpack**, you run:

```mathematica
upx -d <sample>
```

‍

* But **attackers** can tweak packers so those tools break.
* We need a **manual** plan‑B to peel away the packing ourselves

---

**We will be analyzing a sample**<span data-type="text" style="font-size: 22px;"> </span>**Brbbot.exe**<span data-type="text" style="font-size: 20px;"> </span>**and perform static and dynamic analysis to understand it’s behaviour**

‍

```mathematica
> sha256sum brbbot.exe 

> f9227a44ea25a7ee8148e2d0532b14bb640f6dc52cb5b22a9f4fa7fa037417fa  brbbot.exe
```

‍

![image](assets/image-20250509192822-fdctpkw.png)

‍

**The malware is packed using UPX , we will discuss multiple ways to unpack this sample.** 

![image](assets/image-20250509140035-85futps.png)

‍

**Results From PEstudio**

![image](assets/image-20250509135757-euwv2yy.png)

Seeing NPX0/UPX0 and UPX1 is also  a big hint you’ve got a UPX‐packed binary. This could be different incase of other packers used by the malware But a software packed using UPX has section names as UPX, UPX1. but here we have **NPX0.**

This has been done intentionally by the attacker, this way we wont be able to unpack it using the default method.

‍

```mathematica
┌─────────────────────────────┐
│         Packed EXE          │
├─────────────────────────────┤
│ Sections:                   │
│  ├── NPX0  (compressed code)│
│  └── UPX1  (unpacker stub)  │
│                             │
│ Imports:                    │
│  ├── Kernel32.VirtualProtect│
│  ├── Kernel32.LoadLibraryA  │
│  └── Kernel32.GetProcAddress│
│                             │
│ Strings:                    │
│  └── (Mostly none —         │
│       data appears random)  │
└─────────────────────────────┘

```

‍

‍

```mathematica
upx -d <sample>
```

‍

![image](assets/image-20250509140413-ehalqqg.png)

‍

**Unpacking Using Binary Patching**

![image](assets/image-20250509140820-qjn3ka5.png)

**To unpack this we can change the NPX0 to UPX0 in a Hexeditor.**  

‍

![image](assets/image-20250509142827-24czzhs.png)

‍

![image](assets/image-20250509142612-uvj4v1a.png)

‍

![image](assets/image-20250509143027-6ituq3v.png)

‍

**Replacing the values.**

```mathematica
bless brbbot.exe
```

‍

![image](assets/image-20250509144206-k295d9y.png)

save the file , and unpack it using upx

```mathematica
upx -d brbbot_patched.exe 
```

‍

**Unpacked Binary(brbbot.exe)** 

![image](assets/image-20250428211915-3irv46p.png)

Legitimate executables use names like `.text`​, `.rdata`​, `.data`​ or `.rsrc`​.

‍

```mathematica
┌─────────────────────────────┐
│        Original EXE         │
├─────────────────────────────┤
│ Sections:                   │
│  ├── .text     (code)       │
│  ├── .data     (data)       │
│  └── .rdata    (IAT, etc.)  │
│                             │
│ Imports:                    │
│  ├── Win32 APIs:            │
│  │    - CreateFileA         │
│  │    - send, recv          │
│  │    - RegOpenKeyEx        │
│  │    - ...                 │
│                             │
│ Strings:                    │
│  ├── "C:\Windows\..."       │
│  ├── "http://malicious"     │
│  └── "Hello, world"         │
└─────────────────────────────┘

```

‍

**Entropy**

![image](assets/image-20250428213521-btkg0vc.png)

‍

### <span data-type="text" style="font-size: 20px;">What is Entropy?</span>

* A measure of **randomness** or **disorder** in data.
* **Range**: 0.0 (perfectly uniform—every byte the same) to 8.0 (perfectly random all 256 byte-values equally likely).

* **Normal code/data** isn’t purely random: machine-code opcodes, ASCII strings, import tables, resource blobs →<span data-type="text" style="color: var(--b3-font-color8);"> </span>**entropy ≈ 5–6**<span data-type="text" style="color: var(--b3-font-color8);">.</span>
* **Compressed/encrypted** (packed) data looks random →<span data-type="text" style="color: var(--b3-font-color7);"> </span>**entropy**<span data-type="text" style="color: var(--b3-font-color8);"> </span> **&gt;** <span data-type="text" style="color: var(--b3-font-color8);"> </span>**7.5**

‍

```mathematica
Entropy → 
0.0 ─┬───────┬───────┬───────┬───────┬─ 8.0
     1       3       5       7       8
     │   low    normal    high(random)

```

‍

**Packed with UPX**

```pgsql
+--------+---------------+----------------+-------------------------------------------------------------+
| Section|   Raw-Size    |  Virtual-Size  | What this means                                             |
+--------+---------------+----------------+-------------------------------------------------------------+
| NPX0   |     0 bytes   | 110,592 bytes  | On disk it’s empty; Windows reserves ~108 KB in RAM         |
|        |               |                | as a placeholder for unpacked code.                         |
+--------+---------------+----------------+-------------------------------------------------------------+
| UPX1   |  34,816 bytes |  36,864 bytes  | On disk holds the UPX-compressed blob; Windows maps ~36 KB  |
|        |               |                | for it in memory, and its stub unpacks the real code into   |
|        |               |                | the NPX0 section at runtime.                                |
+--------+---------------+----------------+-------------------------------------------------------------+
```

‍

```pgsql
On Disk:                     In Memory:
+----------------------+     +----------------------+
| UPX1 │█████ (34K)    |  ─► | UPX1 │████ (36K)     |
| NPX0 │      (0K)     |     | NPX0 │████ (108K)    |
+----------------------+     +----------------------+
```

‍

* **NPX0 raw-size**  **=**  **0**  
  → There is *no actual data* on disk for that section.
* **NPX0 virtual-size**  **&gt;**  **0**  
  → Windows will carve out that much space in RAM when you run the program.

* **UPX1 raw-size**  **&gt;**  **0**  
  → This is the compressed blob the packer stub will execute.
* **UPX1 virtual-size** slightly larger due to section alignment rounding.+

‍

‍

**unpacking within memory**

***When malware authors pack a program, they compress or encrypt the real payload, so it's hidden in the file on disk. When the program runs, it unpacks itself in memory, and the real malicious code becomes visible only while it's running.***

Most packers don't encrypt memory after unpacking — they only hide content on disk. So by watching memory while the malware runs, you bypass the packing layer. This is a core dynamic analysis trick.

‍

**What is ImageBase?** 

![image](assets/image-20250429105955-t4mk3wh.png)

‍

* When you compile a Windows program, the compiler writes a **preferred load address** into the EXE header called the **ImageBase** (e.g. ​0x140000000).
* This is merely a **suggestion** to Windows: “Please load me at this address in memory.”

* If ASLR is **enabled**, Windows can **ignore** the ImageBase suggestion and load the program at a **random** address each time it runs.
* If ASLR is **disabled**, Windows will honor the ImageBase and load the program at that exact address.

‍

**But Why disable ASLR for unpacking?** 

***so we are going to open the specimen in CFF explorer ---&gt; optional headers ---&gt; click here***

![image](assets/image-20250429111218-uiua79h.png)

dll characteristics : that is because originally dlls would have aslr but executables would not and then microsoft changes so both could have it 

‍

![image](assets/image-20250429111723-6pblclx.png)

```mathematica
CLick on file ---> save ---> overwirite the original file --> yes
```

‍

So now your prorgam will run on image base, anytime it runs

```mathematica
https://github.com/DidierStevens/DidierStevensSuite

we can disable the DynamicBase flag using the command-line tool
setdllcharacteristics by Didier Stevens. This tool is available as free. To disable the flag, invoke the tool with the -d
parameter.
```

![image](assets/image-20250430195813-8aofp6z.png)

‍

**STEPS TO VERIFY MALWARE IS UNPACKED IN MEMORY**

```markdown
Step 1: Run the packed malware sample (malware.exe)
        [As Administrator, in a safe  environment]

Step 2: Open Process Hacker/any other tool
        [A tool like Task Manager but more powerful]

Step 3: Find the brbbot.exe process
        Right-click > Properties

Step 4: Go to:
        Memory > Strings... > [Set "Minimum length" to 10] > OK

Step 5: Analyze the output
        Look at readable strings found in memory.
        These may not be visible in the packed EXE file itself.

```

We ’re **not reading the file on disk**, We 're **reading the live memory** of the process to get unpacked strings.

We want to **dump (extract)**  the unpacked version of the malware from **memory** to a file, so we can analyze the real code statically.

‍

**Why Do We Dump from Memory?** 

```markdown
[On Disk: brbbot.exe] → Packed, obfuscated, unreadable
            ↓
[In Memory: Running Process] → Fully unpacked, real code visible!
            ↓
[Dump] → Save that clean, unpacked version to analyze

```

‍

***But there is a problem: Dumped Executables Are Often Broken***

we will be using Scylla a **Windows tool** used in reverse engineering to **rebuild the Import Address Table (IAT)**  of a  (Portable Executable) file.

![image](assets/image-20250430114230-zsg4men.png)

Open Scylla64 and choose brbbot.exe, we are going to attach it, its very much like a debugger, with a debugger you can attach to a running program and start debugging it even though the program was already running we do the same thing with Scylla, we click on brbbot as our choice and down in the bottom theres a little log window.

‍

![image](assets/image-20250430114629-etpcg0o.png)

‍

![image](assets/image-20250430120136-44v205i.png)

![image](assets/image-20250430120206-hhsxov3.png)

‍

![image](assets/image-20250430121108-h0x0jos.png)

‍

**Dumped EXEs Often Still Don’t Work**

Even after using Scylla to dump a process and fix the Import Address Table , the dumped file often crashes when you try to run it. Because the **Entry Point**  still points to the **unpacking stub** the small bit of code that unpacks the real code into memory.

‍

Before: Packed EXE on Disk

```mathematica
+---------------------+
| .text (stub code)   |  ← Entry Point here (at the unpacking stub)
+---------------------+
| Compressed Code     |
| Compressed Data     |
+---------------------+
| Import Table (fake) |
+---------------------+
```

When loaded into memory, the stub runs, unpacks the real code, fixes imports dynamically, then jumps to the real OEP.

‍

After: Process is Unpacked in Memory

```mathematica
+---------------------+
| Real Code in Memory |
| Real OEP is here    |  ← We need to point EP to here!
+---------------------+
| Real IAT (rebuilt)  |
+---------------------+
| .data, .rdata, etc. |
+---------------------+
```

‍

At this stage, everything is **ready in memory**, and Scylla can dump it. So we:

1. Attach Scylla to this running process.
2. Dump it to disk.
3. Use “IAT Autosearch” to rebuild the Import Address Table.
4. Click **Dump**.

But... we **forgot one thing!**

‍

**Dumped EXE Still Points to Old Stub**

```mathematica
Dumped EXE from Scylla:

+-------------------------+
| Entry Point → Stub Code|  ← ❌ This stub tries to unpack again
+-------------------------+
| Real Code is here       |
| Real OEP is here        |
+-------------------------+
```

As  a result: The dumped file crashes

‍

**Lets load the malware inside**<span data-type="text" style="font-size: 20px;"> </span>**x64debug**<span data-type="text" style="font-size: 20px;"> </span>**and find its entry point (unpacking stub)** 

![image](assets/image-20250507090509-epx5jbi.png)

‍

![image](assets/image-20250507090650-zsh3rlg.png)

‍

![image](assets/image-20250507090808-h0t8gmy.png)

![image](assets/image-20250507090911-iluayv2.png)

‍

**Scylla comes as plugin for x64 debugger, we will use that for our work.** 

![image](assets/image-20250507091002-2c6off3.png)

After carefully dumping the process from memory and correcting its structure, we now have a **clean, working executable** that is ready for both static and dynamic analysis.

‍
