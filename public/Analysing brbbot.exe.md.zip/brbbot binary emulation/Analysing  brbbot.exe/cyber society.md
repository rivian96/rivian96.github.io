# cyber society

1. rules and regulations
2. ctf (simple) can take from tryhack me and pico ctf etc. and pi
3. ‍

‍
